# -*- coding: UTF-8 -*-
module RRD
  module Version  #:nodoc: all
    MAJOR = 0
    MINOR = 2
    PATCH = 7
    STRING = "#{MAJOR}.#{MINOR}.#{PATCH}"
  end
end