#!/bin/bash
set -ev

cd /tmp
git clone https://github.com/keras-team/keras.git

source activate py27
python keras/examples/mnist_cnn.py || exit 1
source deactivate

source activate py36
python keras/examples/mnist_cnn.py || exit 1
source deactivate

rm -rf keras
