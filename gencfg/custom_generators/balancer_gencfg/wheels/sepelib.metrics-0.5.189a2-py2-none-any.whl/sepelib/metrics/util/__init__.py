"""
Unclassified utilities.
"""
