"""
Greenlet friendly yandex services APIs.
"""
from requests import RequestException


class ApiRequestException(RequestException):
    """Common exception for API requests"""
