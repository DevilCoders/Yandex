"""Kafka http proxy mock for unit tests."""

from __future__ import unicode_literals

import contextlib
import os
import shutil
import socket
import subprocess
import time
import tarfile
import textwrap

import requests
import pytest

import sepelib.subprocess.util
from sepelib.yandex.kafka_http_proxy.client import KafkaHttpProxyClient

_KAFKA_VERSION = "0.9.0.1"
_START_TIMEOUT = 30
_PARTITIONS = 1
_POLLING_INTERVAL = 0.01


def pytest_addoption(parser):
    parser.addoption("--kafka", help="path to kafka directory")
    parser.addoption("--kafka-http-proxy", help="path to kafka-http-proxy", default='kafka-http-proxy')


class _KafkaHttpProxy(object):
    """Mocks kafka-http-proxy"""

    def __init__(self, path, tmpdir, kafka):
        """
        :type path: unicode
        :type kafka: _Kafka
        """
        self._host = "localhost"
        self._port = _get_free_port(self._host)
        self._process = None
        self._temp_dir = tmpdir
        self._kafka = kafka
        self._output = self._temp_dir.join('kafka-http-proxy.out')
        self._output_fd = None
        self.client = KafkaHttpProxyClient(url='http://{}/'.format(self.host))

        try:
            self.__start(path)
        except:
            self.kill()
            raise

    @property
    def host(self):
        return "{}:{}".format(self._host, self._port)

    def kill(self):
        if self._process is not None:
            sepelib.subprocess.util.terminate(self._process)
            self._process = None

        if self._output_fd is not None:
            self._output_fd.close()
            self._output_fd = None

    def __start(self, path):
        self._output_fd = self._output.open('w')

        config = textwrap.dedent('''
            [global]
            pidfile = {0}/kafka-http-proxy.pid
            logfile = {0}/proxy.log
            verbose = false

            [broker]
            AllowTopicCreation = true
            '''.format(self._temp_dir.strpath)
        )
        config_file = self._temp_dir.join('kafka-http-proxy.cfg')
        config_file.write(config)
        self._process = subprocess.Popen([path,
                                          '-config', config_file.strpath,
                                          '-brokers', self._kafka.host,
                                          '-addr', self.host],
                                         stdout=self._output_fd,
                                         stderr=self._output_fd,
                                         env=dict(os.environ))
        _wait_for_start(self._process, self._host, self._port, self._output)


class _Kafka(object):
    """Mocks Kafka"""

    def __init__(self, path, tmpdir, zookeeper):
        """
        :type zookeeper: sepelib.zookeeper.mock._ZooKeeper
        """
        self._host = "localhost"
        self._port = _get_free_port(self._host)
        self._process = None
        self._temp_dir = tmpdir
        self._zookeeper = zookeeper
        self._output = self._temp_dir.join('kafka.out')
        self._output_fd = None
        self._partitions = _PARTITIONS

        try:
            self.__start(path)
        except:
            self.kill()
            raise

    @property
    def host(self):
        return "{}:{}".format(self._host, self._port)

    def kill(self):
        if self._process is not None:
            sepelib.subprocess.util.terminate(self._process)

        if self._output_fd is not None:
            self._output_fd.close()

    def __start(self, path):
        self._output_fd = self._output.open('w')

        config = [
            'broker.id=0',
            'port={}'.format(self._port),
            'log.dirs={}'.format(self._temp_dir.strpath),
            'zookeeper.connect={}'.format(self._zookeeper.hosts),
            'num.partitions={}'.format(self._partitions),
            'offsets.topic.num.partitions={}'.format(self._partitions),
        ]

        config_file = self._temp_dir.join('kafka.properties')
        config_file.write('\n'.join(config))

        log4j_file = self._temp_dir.join('log4j.properties')
        log4j_file.write(textwrap.dedent('''
            log4j.rootLogger=INFO, stdout
            log4j.appender.stdout=org.apache.log4j.ConsoleAppender
            log4j.appender.stdout.layout=org.apache.log4j.PatternLayout
            log4j.appender.stdout.layout.ConversionPattern=[%d] %p %m (%c)%n
        '''))

        env = dict(os.environ)

        # OS X:
        # Prevent java from appearing in menu bar, process dock and from activation of the main workspace on run.
        env.update({
            "JAVA_TOOL_OPTIONS": "-Djava.awt.headless=true",
            "KAFKA_LOG4J_OPTS": "-Dlog4j.configuration=file:{}".format(log4j_file.strpath),
        })

        self._process = subprocess.Popen([os.path.join(path, "bin", "kafka-server-start.sh"), config_file.strpath],
                                         stdout=self._output_fd,
                                         stderr=self._output_fd,
                                         env=env)

        _wait_for_start(self._process, self._host, self._port, self._output)


@pytest.fixture
def kafka_http_proxy(request, _kafka, tmpdir):
    proxy = _KafkaHttpProxy(path=request.config.option.kafka_http_proxy,
                            tmpdir=tmpdir,
                            kafka=_kafka)
    request.addfinalizer(proxy.kill)
    return proxy


@pytest.fixture
def _kafka(request, _kafka_dist, tmpdir, zookeeper):
    kafka = _Kafka(_kafka_dist, tmpdir, zookeeper)
    request.addfinalizer(kafka.kill)
    return kafka


@pytest.fixture(scope="session")
def _kafka_dist(request):
    dist_path = request.config.option.kafka
    if dist_path is not None:
        return dist_path

    dist_path = ".kafka"
    if os.path.exists(dist_path):
        return dist_path

    tmp_dist_path = dist_path + ".tmp"
    if os.path.exists(tmp_dist_path):
        shutil.rmtree(tmp_dist_path)

    url = "http://apache.claz.org/kafka/{0}/kafka_2.11-{0}.tgz".format(_KAFKA_VERSION)
    response = requests.get(url, stream=True)
    if response.status_code != requests.codes.ok:
        raise Exception("{}: {}".format(url, response.reason))

    with tarfile.open(fileobj=response.raw, mode="r|gz") as dist:
        dist.extractall(tmp_dist_path)

    os.rename(os.path.join(tmp_dist_path, 'kafka_2.11-{0}'.format(_KAFKA_VERSION)), dist_path)
    os.rmdir(tmp_dist_path)
    return dist_path


def _get_free_port(host):
    with contextlib.closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((host, 0))
        return sock.getsockname()[1]


def _wait_for_start(process, host, port, output):

    start_timeout = time.time() + _START_TIMEOUT

    while process.poll() is None and time.time() < start_timeout:
        try:
            socket.create_connection((host, port)).close()
        except socket.error:
            time.sleep(_POLLING_INTERVAL)
        else:
            break
    else:
        if process.poll() is None:
            raise Exception("Unable to connect to the server. Output:\n{}".format(output.read()))
        else:
            raise Exception("Failed to start binary, return code {}. Output:\n{}".format(process.poll(), output.read()))
