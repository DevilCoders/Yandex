# -*- coding: utf-8 -*-
from sepelib.yandex import ApiRequestException


class KafkaHttpProxyClientError(ApiRequestException):
    pass


class KafkaTopicOffsetOutOfRangeError(KafkaHttpProxyClientError):
    pass


class KafkaOffsetNotFoundError(KafkaHttpProxyClientError):
    pass


class KafkaHttpProxyRequestTimeout(KafkaHttpProxyClientError):
    pass
