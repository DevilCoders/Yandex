# -*- coding: utf-8 -*-
import random
import hashlib


class KafkaHttpProxyProducer(object):
    """
    Producer for the kafka topic
    """

    def __init__(self, topic, client):
        """
        :type topic: str | unicode
        :type client: sepelib.yandex.kafka.client.KafkaHttpProxyClient
        """
        self._topic = topic
        self._client = client
        self._partitions_count = None

    def _get_partition_from_key(self, partition_key):
        """
        :type partition_key: str | unicode
        :rtype: int
        """
        digest = hashlib.sha1(partition_key).hexdigest()
        return int(digest, 16) % self._partitions_count

    def produce(self, message, partition_key=None):
        """
        :type message: dict | list | tuple
        :type partition_key: str | unicode | NoneType
        :rtype: KafkaPartitionOffset
        """
        if self._partitions_count is None:
            topic_info = self._client.get_topic_info(self._topic)
            self._partitions_count = len(topic_info.partitions)

        if partition_key is None:
            partition = random.randint(0, self._partitions_count - 1)
        else:
            partition = self._get_partition_from_key(partition_key)

        return self._client.produce(message, self._topic, partition)
