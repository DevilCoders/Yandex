"""
Common http utilities.
"""
