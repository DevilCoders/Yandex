"""Mocks MongoDB database for Unit Tests.

Note: this module is not thread-safe.
"""

from __future__ import unicode_literals

import atexit
import contextlib
import errno
import json
import shutil
import socket
import subprocess
import tempfile
import time

import mongoengine
import mongoengine.connection

from sepelib.mongo.util import get_registered_models


_MONGODB = None
_START_TIMEOUT = 30
_POLLING_INTERVAL = 0.01
_TERMINATION_TIMEOUT = 10


class ObjectMocker(object):
    """
    A handy object for mocking MongoEngine objects which remembers all created objects and have assertion methods to
    ensure that the database has been changed that way you expected.
    """

    def __init__(self, cls, defaults={}):
        self.__cls = cls
        self.__defaults = defaults
        self.__objects = []

        cls.ensure_indexes()

    def add(self, obj):
        """Adds an object to the list of tracked objects."""

        self.__objects.append(obj)

    def remove(self, obj):
        """Stops tracking the specified object."""

        self.__objects = [other for other in self.__objects if other is not obj]

    @property
    def objects(self):
        """Returns the list of tracked objects."""

        return self.__objects

    def mock(self, overrides={}, add=True, save=True):
        """Mocks an object."""

        kwargs = self.__defaults.copy()
        kwargs.update(overrides)

        obj = self.__cls(**kwargs)
        if save:
            obj.save(force_insert=True)
        if add:
            self.add(obj)

        return obj

    def assert_equal(self, ignore_fields=[]):
        """Asserts that the controlled objects are equal to the objects in the database."""

        def obj_to_dict(objects):
            objs = []

            for obj in objects:
                obj = json.loads(obj.to_json())

                for field in ignore_fields:
                    if field in obj:
                        del obj[field]

                objs.append(obj)

            objs.sort(key=lambda obj: obj["_id"])
            return objs

        objects = obj_to_dict(self.objects)
        db_objects = obj_to_dict(self.__cls.objects)

        assert objects == db_objects


class _MongoDb(object):
    """Mocks MongoDB database."""

    def __init__(self):
        self.connected = False
        self.empty = True
        self.dirty = False

        self.__host = "localhost"
        self.__port = self.__get_free_port()
        self.__db_path = None
        self.__output = None
        self.__process = None

        try:
            self.__start()
        except:
            self.kill()
            raise

    def __del__(self):
        self.kill()

    @property
    def host(self):
        return "{}:{}".format(self.__host, self.__port)

    def kill(self):
        if self.__process is not None:
            self.__kill_process()

        if self.__output is not None:
            self.__output.close()
            self.__output = None

        if self.__db_path is not None:
            shutil.rmtree(self.__db_path)
            self.__db_path = None

    def __kill_process(self):
        terminate_timeout = time.time() + _TERMINATION_TIMEOUT

        while self.__process.poll() is None:
            timed_out = time.time() >= terminate_timeout

            try:
                if timed_out:
                    self.__process.kill()
                else:
                    self.__process.terminate()
            except EnvironmentError as e:
                if e.errno == errno.ESRCH:
                    break
                else:
                    raise
            else:
                time.sleep(_POLLING_INTERVAL)

        self.__process = None

    def __start(self):
        self.__db_path = tempfile.mkdtemp(prefix="mongodb-mock-", dir="/var/tmp")
        self.__output = tempfile.NamedTemporaryFile(bufsize=0)

        args = [
            "mongod", "--nohttpinterface", "--nojournal", "--noprealloc",
            "--dbpath", self.__db_path, "--port", str(self.__port)]

        self.__process = subprocess.Popen(
            args, stdout=self.__output, stderr=self.__output)

        self.__wait_for_start()

    def __wait_for_start(self):
        start_timeout = time.time() + _START_TIMEOUT

        while self.__process.poll() is None and time.time() < start_timeout:
            try:
                socket.create_connection((self.__host, self.__port)).close()
            except socket.error:
                time.sleep(_POLLING_INTERVAL)
            else:
                break
        else:
            if self.__process.poll() is None:
                raise Exception(
                    "Unable to connect to the MongoDB server. "
                    "MongoDB output:\n" + self.__get_output())
            else:
                raise Exception("Failed to start MongoDB:\n" + self.__get_output())

    def __get_free_port(self):
        with contextlib.closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((self.__host, 0))
            return sock.getsockname()[1]

    def __get_output(self):
        with open(self.__output.name) as output:
            return output.read()


class Database(object):
    """Represents a mocked database."""

    _system_databases = ("admin", "local")

    def __init__(self, lightweight=False):
        self.__lightweight = lightweight
        self.__mongodb = mongodb = _mock_mongodb()

        if not lightweight:
            self.__disconnect()

        self.connection = mongoengine.connect("mock", host=mongodb.host, use_greenlets=True)
        mongodb.connected = True

        try:
            if lightweight:
                if mongodb.dirty:
                    self.__erase()
            else:
                if not mongodb.empty:
                    self.__drop_databases()

            mongodb.empty = False
            mongodb.dirty = True
        except:
            self.close()
            raise

    def close(self):
        if not self.__lightweight:
            self.__drop_databases()
            self.__disconnect()

    def __erase(self):
        for db_name in self.connection.database_names():
            if db_name in self._system_databases:
                continue

            db = self.connection[db_name]
            for collection_name in db.collection_names(include_system_collections=False):
                db[collection_name].remove({})

        self.__mongodb.dirty = False

    def __drop_databases(self):
        for db_name in self.connection.database_names():
            if db_name not in self._system_databases:
                self.connection.drop_database(db_name)

        self.__mongodb.dirty = False
        self.__mongodb.empty = True

    def __disconnect(self):
        disconnect()
        self.__mongodb.connected = False


def mock_database(request):
    """pytest fixture for database mocking."""

    db = Database()
    request.addfinalizer(db.close)
    return db.connection


def disconnect():
    """Disconnects from mocked database."""

    # MongoEngine caches a lot of data. Try to purge as much caches as we can.

    for model in get_registered_models():
        try:
            del model._collection
        except AttributeError:
            pass

    for alias in mongoengine.connection._connections.keys():
        mongoengine.connection.disconnect(alias)

    mongoengine.connection._connection_settings.clear()


def _mock_mongodb():
    global _MONGODB

    if _MONGODB is None:
        _MONGODB = _MongoDb()
        atexit.register(_MONGODB.kill)

    return _MONGODB
