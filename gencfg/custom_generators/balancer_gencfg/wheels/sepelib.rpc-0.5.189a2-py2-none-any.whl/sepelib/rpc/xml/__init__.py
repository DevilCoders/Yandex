"""
Simple module to perform XMLRPC calls
"""
from .request import xmlrpc_call
