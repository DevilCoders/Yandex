import xmlrpclib
import socket

import requests
from requests import RequestException


def xmlrpc_call(url, method, params, timeout=10, exc_cls=Exception, session=None, headers=None):
    """
    Simple general purpose requests based XMLRPC call.
    :param url: url to call
    :param method: method name
    :param params: parameters for method being called
    :param timeout: response timeout
    :param exc_cls: what exception class should be raised on error
    :param session: optional requests session object to be used
    :param headers: optional headers dictionary
    :return: object
    """
    if not isinstance(params, tuple):
        params = params,
    data = xmlrpclib.dumps(params, methodname=method)
    session = session or requests.Session()
    if headers:
        headers['Content-Type'] = 'text/xml'
    else:
        headers = {'Content-Type': 'text/xml'}
    try:
        resp = session.post(url,
                            data=data, headers=headers,
                            timeout=timeout)
    except socket.error as e:
        raise exc_cls("socket error: {0}".format(e.strerror), url)
    except RequestException as e:
        raise exc_cls('connection error: {0}'.format(str(e)), url)
    resp.raise_for_status()
    answ, _ = xmlrpclib.loads(resp.content)
    # answer is a tuple
    return answ[0]
