# coding=utf-8

import socket
import logging
from cStringIO import StringIO
from uuid import uuid4
from functools import wraps

import requests
from gevent import Timeout
from requests.adapters import HTTPAdapter
from thrift.transport import TSocket
from thrift.protocol.TBinaryProtocol import TBinaryProtocol, TBinaryProtocolAccelerated
from thrift.transport import TTransport

from sepelib.core.constants import MEGABYTE
from sepelib.metrics.registry import metrics_inventory
from sepelib.rpc.thrift.transport import TGeventIdleTransport
from sepelib.util.retry import RetrySleeper

COMMON_MAX_RETRIES = 4
CONNECTION_ERRORS = (TTransport.TTransportException,
                     socket.error, socket.gaierror, Timeout,
                     requests.ConnectionError)


class ThriftConnectionError(Exception):
    def __init__(self, host, port, method, message, error):
        self.host = host
        self.port = port
        self.method = method
        self.message = message
        self.error = error

    def __str__(self):
        return 'ThriftConnectionError(host={}, port={}, method={}, message={}, error={})'.format(
            self.host,
            self.port,
            self.method,
            self.message,
            self.error,
        )


class RequestsHttpTransport(TTransport.TTransportBase, object):
    """
    Requests based http transport for thrift RPC.
    It is better than default one:
        * less AttributeErrors here and there
        * by using provided session we can reuse connections
        * by using provided session we can issue several call in parallel for free (no code from us)
    """
    REQ_ID_HEADER = 'X-Req-Id'
    _rbuf = StringIO('')  # empty readonly buffer until we get real one after request
    _headers = {"Content-Type": "application/x-thrift"}

    @staticmethod
    def _gen_reqid(uuid_func=uuid4):
        return str(uuid_func())

    def __init__(self, url, session=None, reqid=None):
        self._url = url
        self._reqid = reqid or self._gen_reqid()
        self._session = session or requests.Session()
        self._wbuf = StringIO()

    def read(self, size):
        return self._rbuf.read(size)

    def readAll(self, size):
        buf = self._rbuf.read(size)
        if len(buf) < size:
            raise EOFError
        return buf

    def write(self, buf):
        self._wbuf.write(buf)

    def flush(self):
        data = self._wbuf.getvalue()
        self._wbuf.close()
        if self._reqid is not None:
            headers = self._headers.copy()
            headers[self.REQ_ID_HEADER] = self._reqid
        else:
            headers = self._headers
        response = self._session.post(self._url, data=data, headers=headers)
        response.raise_for_status()
        # read everything into StringIO
        # this can bring speed ups because all small reads from thrift code won't
        # result in extra system calls
        # StringIO does not create copy - so we simply provide
        # file like API for thrift protocol
        self._rbuf = StringIO(response.content)


class ThriftBinClient(object):
    """
    Клиент thrift API на базе бинарного протокола

    Пробует восстанавливать соединение с сервером прозрачно для пользователя.
    """
    # значение по умолчанию таймаута на вызов одного метода
    DEFAULT_CALL_TIMEOUT = 25

    # максимальное количество попыток снова вызвать метод
    DEFAULT_MAX_TRIES = 4

    NAME = 'bin_thrift'

    DEFAULT_IDLE_BYTE_PERIOD = MEGABYTE

    @classmethod
    def from_config(cls, config):
        """
        Создать объект по конфигу

        :param dict config:
        :return: объект thrift клиента
        :rtype: ThriftClient
        """
        return cls(config['thrift_service'], config['host'], config['port'], config.get('request_timeout'))

    def __init__(self, thrift_client_class, host, port, request_timeout=None, max_tries=None, metrics=None,
                 idle_method=None, idle_byte_period=None):
        """
        :param thrift_client_class: класс thrift-сервиса
        :param host: хост thrift сервера
        :param port: порт thrift сервера
        :param request_timeout: таймаут на один запрос
        :type idle_method: collections.Callable
        :param idle_method: idle method for calling at least each :param idle_byte_period: read bytes
        :type idle_byte_period: int
        """
        self.thrift_client_class = thrift_client_class
        self.host = host
        self.port = port
        self.request_timeout = request_timeout or self.DEFAULT_CALL_TIMEOUT
        self.log = logging.getLogger('{}_client({}:{})'.format(self.NAME, host, port))
        self._metrics = metrics or metrics_inventory.get_metrics('/clients/{}'.format(self.NAME))
        self._client = None
        self.max_tries = max_tries or self.DEFAULT_MAX_TRIES
        self._transport = None
        self._idle_method = idle_method
        self._idle_byte_period = idle_byte_period or self.DEFAULT_IDLE_BYTE_PERIOD

    def get_metrics_dump(self):
        return self._metrics.dump_metrics()

    @property
    def client(self):
        if self._client is None:
            # делаем объект клиента для получения информации про атрибуты
            self._client = self.create_thrift_client_object()
        return self._client

    def create_thrift_client_object(self):
        _socket = TSocket.TSocket(self.host, self.port)
        transport = TTransport.TFramedTransport(_socket)
        if self._idle_method is not None:
            transport = TGeventIdleTransport(transport,
                                             idle_byte_period=self._idle_byte_period,
                                             idle_method=self._idle_method)
        protocol = TBinaryProtocolAccelerated(transport)
        client = self.thrift_client_class.Client(protocol)
        client.transport = transport
        return client

    def __getattr__(self, item):
        if hasattr(self.client, item):
            # каждый раз создаём новый объект клиента
            thrift_client = self.create_thrift_client_object()

            item = getattr(thrift_client, item)
            if hasattr(item, '__call__'):
                # декорируем только методы
                item = self.thrift_api_func_wrapper(thrift_client)(item)
            return item
        else:
            raise AttributeError("'{}' object has no attribute '{}'".format(
                self.__class__.__name__, item
            ))

    def thrift_api_func_wrapper(self, thrift_client):
        """
        Создаёт декоратор для методов thrift объекта
        :return: декоратор для thrift методов
        """
        def _api_func(f):
            """
            Run Thrift RPC function. We need to provide following requirements:
                * several attempts are performed
                * supports requests timeouts
            """
            @wraps(f)
            def run_func(*args, **kwargs):
                sleeper = RetrySleeper(self.max_tries, max_delay=30)
                while True:
                    try:
                        func_timer = self._metrics.timer(f.__name__)
                        total_timer = self._metrics.timer('total_timings')
                        self._metrics.counter('total_calls').inc()
                        # we don't use thrift's setTimeout -
                        # it translates into socket.timeout which
                        # is simply timeout parameter in select system call
                        with Timeout(seconds=self.request_timeout), func_timer.time(), total_timer.time():
                            thrift_client.transport.open()
                            result = f(*args, **kwargs)
                    except CONNECTION_ERRORS as e:
                        self._metrics.counter('conn_error_calls').inc()
                        if not sleeper.increment(exception=False):
                            # raise module specific exception to provide
                            # more information to user
                            raise ThriftConnectionError(
                                self.host, self.port, f.__name__, str(e), e
                            )
                    except Exception:
                        self._metrics.counter('other_error_calls').inc()
                        raise
                    else:
                        self._metrics.counter('successful_calls').inc()
                        return result
                    finally:
                        thrift_client.transport.close()

            return run_func
        return _api_func


class ThriftHttpClient(ThriftBinClient):
    """
    Клиент thrift API на базе http

    Пробует восстанавливать соединение с сервером прозрачно для пользователя.
    """
    NAME = 'http'

    @classmethod
    def _make_http_adapter(cls):
        """
        Make custom http adapter.
        We need maximum pooled connection to be less than attempts.
        Thus we work around situation when we have actually dead connections at hand.
        We achieve this by exhausting connection pool if connections are dead.
        E.g. they can be dropped by ipvs or/and http balancer due to inactivity.

        Proper ways to fix can be:
          * Use SO_KEEPALIVE to minimize having broken connections in the pool.
          * Throw connections coming from pool if they were idle for too long.
        But these ways are hard to implement, there aren't enough hooks in requests library.
        So let's use this hack, should do it. See SEPE-8393 for details.
        """
        max_conn = COMMON_MAX_RETRIES / 2
        return HTTPAdapter(pool_connections=max_conn, pool_maxsize=max_conn)

    def __init__(self, thrift_client_class, host, port, request_timeout=45):
        super(ThriftHttpClient, self).__init__(thrift_client_class, host, port, request_timeout)
        self.uri = 'http://{host}:{port}/'.format(host=host, port=port)

        self._session = requests.Session()
        self._session.trust_env = False
        self._session.mount(self.uri, self._make_http_adapter())

    def close(self):
        self._session.close()

    def create_thrift_client_object(self, reqid=None):
        transport = RequestsHttpTransport(self.uri, self._session, reqid=reqid)
        protocol = TBinaryProtocol(transport)
        # no need to open transport, http client opens it automatically
        client = self.thrift_client_class.Client(protocol)
        return client


class TUnicodeBinaryProtocol(TBinaryProtocol):
    """
    Hack for unicode support
    """

    def writeString(self, msg):
        if isinstance(msg, unicode):
            msg = msg.encode('utf-8')
        TBinaryProtocol.writeString(self, msg)

    def readString(self):
        msg = TBinaryProtocol.readString(self)
        return msg.decode('utf-8')
