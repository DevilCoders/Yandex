"""
Monkey patch for kazoo to fix bugs still opened in upstream
"""
# it's template now as all bugs are fixed

#def patch_issue_NNN():
#    pass


def patch_all():
    pass
