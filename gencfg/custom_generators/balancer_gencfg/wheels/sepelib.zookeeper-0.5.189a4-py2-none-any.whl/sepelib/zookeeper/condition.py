"""Provides distributed condition variable."""

from __future__ import unicode_literals

import logging
import random
import socket
import uuid

from collections import namedtuple

from kazoo.exceptions import NoNodeError, NodeExistsError
from kazoo.protocol.states import EventType, KazooState
from kazoo.retry import KazooRetry

from sepelib.core.exceptions import Error

log = logging.getLogger(__name__)

_NodeVersion = namedtuple("_NodeVersion", ("node_id", "version"))
_NODE_PREFIX = "__condition-listener__"


class Condition(object):
    """Represents a condition variable."""

    def __init__(self, client, path):
        self.__client = client
        self.__path = path

    def signal(self):
        """Signals to a one listener.

        Does nothing if there are no listeners. Doesn't guarantee that the listener will receive the signal.
        """

        tries = 1000
        signaled = False

        try:
            while True:
                listeners = self.__get_listeners()
                if not listeners:
                    break

                listener = random.choice(listeners)

                try:
                    self.__client.set(self.__path + "/" + listener, b"")
                except NoNodeError:
                    tries -= 1
                    if tries <= 0:
                        raise Error("A possible infinite loop error.")
                else:
                    signaled = True
                    break
        except Exception as e:
            raise Error("Unable to signal {} condition: {}", self.__path, e)

        return signaled

    def signal_all(self):
        """Signals to all listeners.

        Does nothing if there are no listeners. Doesn't guarantee that the listener will receive the signal.
        """

        signaled = False

        try:
            for listener in self.__get_listeners():
                try:
                    self.__client.set(self.__path + "/" + listener, b"")
                except NoNodeError:
                    pass
                else:
                    signaled = True
        except Exception as e:
            raise Error("Unable to signal {} condition: {}", self.__path, e)

        return signaled

    def __get_listeners(self):
        try:
            names = self.__client.get_children(self.__path)
        except NoNodeError:
            return []

        return [name for name in names if name.startswith(_NODE_PREFIX)]


class ConditionListenerBase(object):
    """Listens to the specified condition."""

    _retry_timeout = 30

    def __init__(self, client, path):
        self.__lock = client.handler.lock_object()
        self.__client = client
        self.__path = path

        self._node_name = None
        self._node_path = None
        self.__node_version = None

        self.__retry = KazooRetry(max_delay=self._retry_timeout, max_tries=None, sleep_func=client.handler.sleep_func)

    def start(self, async=False):
        if self._node_path is not None:
            raise Error("The listener is already started.")

        try:
            with self.__lock:
                self._clear()
                self._node_name = _NODE_PREFIX + socket.gethostname() + "__" + uuid.uuid4().hex
                self._node_path = self.__path + "/" + self._node_name

            log.debug("Starting %s condition listener...", self._node_path)

            if not async:
                try:
                    self.__retry(self.__client.create, self._node_path, ephemeral=True, makepath=True)
                except NodeExistsError:
                    pass

            with self.__lock:
                self.__client.add_listener(self.__watch_session)

                if async:
                    self.__on_node_missing()
                else:
                    self.__watch_node()

            log.debug("Condition listener %s has started.", self._node_path)
        except Exception as e:
            self.stop()
            raise Error("Failed to start {} condition listener: {}", self._node_path, e)

    def stop(self):
        if not self.__started():
            return

        with self.__lock:
            self.__client.remove_listener(self.__watch_session)
            node_path = self._node_path

            self.__node_version = None
            self._node_path = None
            self._node_name = None

        log.debug("Stopping %s condition listener...", node_path)

        try:
            self.__retry(self.__client.delete, node_path)
        except NoNodeError:
            pass
        except Exception as e:
            log.error("Failed to delete %s condition listener node: %s", node_path, e)

        log.debug("Condition listener %s has stopped.", node_path)

    def _clear(self):
        """
        Clears stored notifications.

        Should be implemented in the derived class.
        """

    def _notify(self):
        """
        Stores a notification.

        Should be implemented in the derived class.
        """

    def __started(self):
        return self._node_name is not None

    def __watch_node(self):
        def on_get_node(result):
            try:
                node_info = result.get()[1]
            except NoNodeError:
                with self.__lock:
                    if self.__started():
                        self.__on_node_missing()
            except Exception as e:
                log.error("Failed to get %s node info: %s.", path, e)
            else:
                with self.__lock:
                    if self.__started():
                        self.__on_node_version(_NodeVersion(node_info.czxid, node_info.version))

        path = self._node_path
        self.__client.get_async(path, watch=self.__on_node_changed).rawlink(on_get_node)

    def __on_node_version(self, node_version):
        if self.__node_version is None or self.__node_version.node_id != node_version.node_id:
            if node_version.version != 0:
                self._notify()
        else:
            if node_version > self.__node_version:
                self._notify()

        self.__node_version = node_version

    def __on_node_missing(self):
        def on_create_node(result):
            try:
                result.get()
            except NodeExistsError:
                pass
            except Exception as e:
                log.error("Failed to create %s node: %s", path, e)
                return

            with self.__lock:
                if self.__started():
                    self.__watch_node()

        path = self._node_path
        self.__client.create_async(path, ephemeral=True, makepath=True).rawlink(on_create_node)

    def __on_node_changed(self, event):
        with self.__lock:
            if self.__started():
                if event.type == EventType.DELETED:
                    self.__on_node_missing()
                else:
                    self.__watch_node()

    def __watch_session(self, state):
        if state == KazooState.CONNECTED:
            with self.__lock:
                if self.__started():
                    self.__on_node_missing()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop()


class ConditionListener(ConditionListenerBase):
    """Listens to the specified condition and stores notifications to the event object."""

    def __init__(self, client, path):
        super(ConditionListener, self).__init__(client, path)
        self.event = client.handler.event_object()

    def _clear(self):
        self.event.clear()

    def _notify(self):
        self.event.set()