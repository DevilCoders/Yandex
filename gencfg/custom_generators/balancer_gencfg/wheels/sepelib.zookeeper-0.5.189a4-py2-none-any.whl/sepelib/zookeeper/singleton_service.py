import os
import logging

import gevent
from gevent.event import Event

from sepelib.gevent import GreenThread
from sepelib.util.retry import RetrySleeper
from sepelib.util.exc.format import format_exc
from .client import CoordError, KazooState, ConnectionClosedError


class SingletonService(GreenThread):
    """
    Singleton service, coordinating through zookeeper.
    Designed to be used as a wrapper for unaware service.
    Service is an object with ``start`` and ``stop`` methods and ``name`` property.
    """
    _UNSET = object()
    # it's a good practice, mentioned in google chubby papers
    # to give up control once in a while
    STANDOFF_TIMEOUT = 12 * 3600
    SINGLETONS_PATH = '/singletons'

    def __init__(self, coord, service, standoff_timeout=_UNSET):
        """
        :param coord: zookeeper client instance
        :param service: service to be wrapped in singleton
        :param standoff_timeout: how often give up leadership (None if never)
        """
        super(SingletonService, self).__init__()
        self.log = logging.getLogger('singleton({})'.format(service.name))
        self.coord = coord
        self.lock = self.coord.lock(os.path.join(self.SINGLETONS_PATH, service.name))
        self.service = service
        self._standoff_timeout = self.STANDOFF_TIMEOUT if standoff_timeout is self._UNSET else standoff_timeout

    @property
    def name(self):
        return self.service.name

    def wait_disconnect(self, timeout=None):
        def set_on_disconnect(state, event):
            if state != KazooState.CONNECTED:
                event.set()
        event = Event()
        listener = lambda state: set_on_disconnect(state, event)
        self.coord.add_listener(listener)
        event.wait(timeout=timeout)
        self.coord.remove_listener(listener)
        return event.is_set()

    def run(self):
        sleeper = RetrySleeper(max_delay=5)

        def cancel_on_disconnect(state):
            # lock doesn't handle disconnect event
            # so do it here
            # when we call cancel - lock.acquire will throw CanceledError
            # which is subclass of CoordError and will be retried
            # better (but longer) way would be add this functionality to lock itself
            # but will do for now
            if state != KazooState.CONNECTED:
                self.lock.cancel()

        while 1:
            self.log.info("acquiring lock...")
            self.coord.add_listener(cancel_on_disconnect)
            try:
                self.lock.acquire()
            except CoordError as e:
                self.log.info(format_exc('failed to acquire lock', e))
                sleeper.increment()
            else:
                # we locked, yey!
                # now start service and wait for session state change
                sleeper.reset()
                self.log.info("became singleton - starting service")
                self.service.start()
                is_disconnected = self.wait_disconnect(self._standoff_timeout)
                if is_disconnected:
                    self.log.warn("disconnected - stopping service")
                    self.service.stop()
                else:
                    self.log.info("was leading for too long, stand off - stopping service")
                    # First we stop service, then release lock
                    # Thus we encounter less races
                    self.service.stop()
                    self.lock.release()
                self.log.info("service stopped")
                # sleep for sometime to let someone take leadership
                gevent.sleep(2)
            finally:
                self.coord.remove_listener(cancel_on_disconnect)

    def stop(self):
        self.log.info("stopping...")
        self.service.stop()
        try:
            self.lock.release()
        except ConnectionClosedError:
            # it's okay if we failed
            # application must be shutting down
            pass
        super(SingletonService, self).stop()
        self.log.info("stopped")


class SingletonObserver(object):
    """
    Utility to introspect singletons from outside
    """
    def __init__(self, zookeeper_client):
        self._zookeeper_client = zookeeper_client

    def list_services(self):
        """
        Get a list of services using singleton service mechanism.
        """
        return self._zookeeper_client.get_children(SingletonService.SINGLETONS_PATH)

    def list_service_instances(self, service):
        """
        Get an ordered list of instances competing to become master.
        """
        lock = self._zookeeper_client.lock(os.path.join(SingletonService.SINGLETONS_PATH, service))
        return lock.contenders()
