"""ZooKeeper mock for unit tests."""

from __future__ import unicode_literals

import contextlib
import os
import shutil
import signal
import socket
import subprocess
import tarfile
import tempfile
import time

import pytest

from kazoo.client import KazooClient
from kazoo.handlers.gevent import SequentialGeventHandler

import requests

import sepelib.subprocess.util


_ZOOKEEPER_VERSION = "3.4.6"


def pytest_addoption(parser):
    parser.addoption("--zookeeper", help="path to ZooKeeper directory")


@pytest.fixture
def zookeeper(request, _zookeeper_server):
    request.addfinalizer(_zookeeper_server.disconnect)
    _zookeeper_server.connect()
    _zookeeper_server.cleanup()
    return _zookeeper_server


class _ZooKeeper(object):
    __host = "localhost"

    # Don't try to set it less than 2000 - kazoo works strangely with such values
    __tick_time = 2000

    def __init__(self, path):
        self.__temp_dir = None
        self.__stdout = None
        self.__stderr = None
        self.__port = None
        self.__process = None
        self.__client = None

        try:
            self.__start(path)
        except:
            self.close()
            raise

    @property
    def timeout(self):
        return float(self.__tick_time) / 1000 * 3 + 1

    def break_temporarily(self):
        os.kill(self.__process.pid, signal.SIGSTOP)
        time.sleep(self.timeout)

        os.kill(self.__process.pid, signal.SIGCONT)
        time.sleep(self.timeout)

    @property
    def client(self):
        return self.__client

    def connect(self):
        self.__client = KazooClient(hosts=self.__hosts(), handler=SequentialGeventHandler())
        self.__client.start()

    def cleanup(self):
        for name in self.__client.get_children("/"):
            if name != "zookeeper":
                self.__client.delete("/" + name, recursive=True)

    def disconnect(self):
        if self.__client is not None:
            self.__client.stop()
            self.__client.close()
            self.__client = None

    def close(self):
        try:
            self.disconnect()

            if self.__process is not None:
                sepelib.subprocess.util.terminate(self.__process)

            if self.__stdout is not None:
                self.__stdout.close()

            if self.__stderr is not None:
                self.__stderr.close()
        finally:
            if self.__temp_dir is not None:
                shutil.rmtree(self.__temp_dir)

    def __start(self, path):
        self.__temp_dir = tempfile.mkdtemp()

        data_path = os.path.join(self.__temp_dir, "data")
        os.mkdir(data_path)

        self.__stdout = open(os.path.join(self.__temp_dir, "stdout"), "w")
        self.__stderr = open(os.path.join(self.__temp_dir, "stderr"), "w")

        self.__port = self.__get_free_port()

        config = [
            "tickTime={}".format(self.__tick_time),
            "dataDir=" + data_path,
            "clientPort={}".format(self.__port),
        ]

        with open(os.path.join(self.__temp_dir, "zoo.cfg"), "w") as config_file:
            config_file.write("\n".join(config))

        env = dict(os.environ)
        env.update({
            "ZOOCFGDIR": self.__temp_dir,

            # OS X:
            # Prevent java from appearing in menu bar, process dock and from activation of the main workspace on run.
            "JAVA_TOOL_OPTIONS": "-Djava.awt.headless=true",
        })

        self.__process = subprocess.Popen([os.path.join(path, "bin", "zkServer.sh"), "start-foreground"],
                                          stdout=self.__stdout, stderr=self.__stderr, env=env)

    def __get_free_port(self):
        with contextlib.closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
            sock.bind((self.__host, 0))
            return sock.getsockname()[1]

    def __hosts(self):
        return "{}:{}".format(self.__host, self.__port)

    @property
    def hosts(self):
        return self.__hosts()


@pytest.fixture(scope="session")
def _zookeeper_server(request, _zookeeper_dist):
    mock = _ZooKeeper(_zookeeper_dist)
    request.addfinalizer(mock.close)
    return mock


@pytest.fixture(scope="session")
def _zookeeper_dist(request):
    dist_path = request.config.option.zookeeper
    if dist_path is not None:
        return dist_path

    dist_path = ".zookeeper"
    if os.path.exists(dist_path):
        return dist_path

    tmp_dist_path = dist_path + ".tmp"
    if os.path.exists(tmp_dist_path):
        shutil.rmtree(tmp_dist_path)

    url = "http://apache.claz.org/zookeeper/zookeeper-{0}/zookeeper-{0}.tar.gz".format(_ZOOKEEPER_VERSION)
    response = requests.get(url, stream=True)
    if response.status_code != requests.codes.ok:
        raise Exception("{}: {}".format(url, response.reason))

    with tarfile.open(fileobj=response.raw, mode="r|gz") as dist:
        dist.extractall(tmp_dist_path)

    os.rename(os.path.join(tmp_dist_path, "zookeeper-{}".format(_ZOOKEEPER_VERSION)), dist_path)
    os.rmdir(tmp_dist_path)
    return dist_path
