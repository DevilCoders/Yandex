"""Provides distributed locks."""

from __future__ import unicode_literals

import datetime
import functools
import logging
import random
import socket
import threading
import uuid

import gevent
import gevent.lock

from kazoo.exceptions import KazooException, LockTimeout, NoNodeError, NotEmptyError
from kazoo.protocol.states import KazooState
from kazoo.recipe.lock import Lock as KazooLock
from kazoo.retry import KazooRetry, ForceRetryError

_UNDEFINED = object()

log = logging.getLogger(__name__)


class ConnectionError(KazooException):
    def __init__(self, message="ZooKeeper connection is broken."):
        super(ConnectionError, self).__init__(message)


class LockIsLostError(BaseException):
    def __init__(self, message):
        super(LockIsLostError, self).__init__(message)

    def to_exception(self):
        """Convert the object to an object derived from Exception."""

        return ConnectionError(unicode(self))


class Lock(object):
    """Fork of kazoo.recipe.lock.Lock.

    Differences from kazoo's Lock:
    * name parameter in __init__() (highly recommended to be specified). See `_GarbageCollector` for details.
    * blocking parameter in __init__()
    * timeout parameter in __init__()
    * Removes the path on release()
    * Less public attributes
    * Don't have cancel()
    * release() don't return anything
    * Fixed bugs and race conditions

    Please see also `_GarbageCollector` for details.

    See `kazoo.recipe.lock.Lock` for interface details.
    """

    _node_name = "__lock__"
    _default_identifier = None
    _retry_timeout = 30

    def __init__(self, client, path, name=None, identifier=None, blocking=True, timeout=None):
        if name is None:
            register_lock_path(path)
        else:
            register_lock_parent_path(path)

        self.__client = client
        self.__path = path if name is None else path + "/" + name
        self.__blocking = blocking
        self.__timeout = timeout
        self.__acquired = False

        # Props to Netflix Curator for this trick. It is possible for our create request to succeed on the server, but
        # for a failure to prevent us from getting back the full path name. We prefix our lock name with a uuid and can
        # check for its presence on retry.
        self.__node_prefix = uuid.uuid4().hex + self._node_name

        if identifier is None:
            if Lock._default_identifier is None:
                Lock._default_identifier = socket.gethostname()
            identifier = Lock._default_identifier
        self.__data = identifier.encode("utf-8")

        # Just for optimization for locking without contenders
        self.__assured_path = False
        self.__create_tried = False

        self.__node = None
        self.__wake_event = client.handler.event_object()
        self.__retry = KazooRetry(max_delay=self._retry_timeout, max_tries=None, sleep_func=client.handler.sleep_func)

    @property
    def client(self):
        return self.__client

    @property
    def path(self):
        return self.__path

    def acquire(self, blocking=_UNDEFINED, timeout=_UNDEFINED):
        if self.__acquired:
            raise RuntimeError("The lock is already acquired.")

        if blocking is _UNDEFINED:
            blocking = self.__blocking

        if timeout is _UNDEFINED:
            timeout = self.__timeout

        retry = self.__retry.copy()
        retry.deadline = timeout

        try:
            self.__acquired = retry(self.__acquire, blocking, timeout)
        except BaseException as error:
            try:
                # Use lost_lock_retry() wrapper to properly recover in case when the lock is being locked inside other
                # InterruptableLock.
                lost_lock_retry(self.__retry)(self.__best_effort_cleanup)
            except Exception:
                log.exception("Failed to clean up lock on %s:", self.__path)

            raise error

        if not self.__acquired:
            # Use lost_lock_retry() wrapper to support the case when the lock is being locked inside other
            # InterruptableLock.
            lost_lock_retry(self.__retry)(self.__cleanup)

        return self.__acquired

    def acquired(self):
        return self.__acquired

    def release(self):
        if not self.__acquired:
            raise RuntimeError("The lock is not acquired.")

        # Use lost_lock_retry() wrapper to handle the case when the lock is locked inside other InterruptableLock
        return lost_lock_retry(self.__retry)(self.__release)

    def __acquire(self, blocking, timeout):
        if not self.__assured_path:
            self.__client.ensure_path(self.__path)
            self.__assured_path = True

        if self.__create_tried:
            self.__find_node()

        if self.__node is None:
            self.__create_tried = True
            self.__create_node()

        self.__client.add_listener(self.__watch_session)

        try:
            while True:
                self.__wake_event.clear()

                try:
                    lock_nodes = self.__get_sorted_lock_nodes()
                except NoNodeError:
                    # The lock path doesn't exists already. Probably we are recovering from a session failure and our
                    # ephemeral node was removed.
                    raise ForceRetryError()

                try:
                    our_index = lock_nodes.index(self.__node)
                except ValueError:
                    # Somehow we aren't in the children. Probably we are recovering from a session failure and our
                    # ephemeral node was removed.
                    raise ForceRetryError()

                if our_index == 0:
                    return True

                if not blocking:
                    return False

                predecessor = self.__path + "/" + lock_nodes[our_index - 1]

                if self.__client.exists(predecessor, self.__watch_predecessor):
                    if not self.__wake_event.wait(timeout):
                        raise LockTimeout("Failed to acquire lock on {} after {} seconds".format(self.__path, timeout))
        finally:
            self.__client.remove_listener(self.__watch_session)

    def __release(self):
        self.__cleanup()
        self.__acquired = False
        self.__assured_path = False
        self.__create_tried = False
        self.__node = None

    def __best_effort_cleanup(self):
        self.__find_node()
        self.__cleanup()

    def __create_node(self):
        create_path = self.__path + "/" + self.__node_prefix

        try:
            path = _retry_on(self.__client.create, NoNodeError, lambda: self.__client.ensure_path(self.__path))(
                create_path, self.__data, ephemeral=True, sequence=True)
        except NoNodeError:
            raise KazooException(
                "Failed to acquire '{}' lock: There are too many unexpected race conditions or "
                "there is a logical error somewhere in the lock's logic.".format(self.__path))

        self.__node = path[len(self.__path) + 1:]

    def __find_node(self):
        try:
            children = self.__client.get_children(self.__path)
        except NoNodeError:
            self.__node = None
        else:
            for child in children:
                if child.startswith(self.__node_prefix):
                    self.__node = child
                    break
            else:
                self.__node = None

    def __get_sorted_lock_nodes(self):
        separator = self._node_name
        lock_nodes = [child for child in self.__client.get_children(self.__path) if separator in child]
        # can't just sort directly: the node names are prefixed by uuids
        lock_nodes.sort(key=lambda node: node[node.find(separator) + len(separator):])
        return lock_nodes

    def __cleanup(self):
        if self.__node is not None:
            try:
                self.__client.delete(self.__path + "/" + self.__node)
            except NoNodeError:
                pass

        try:
            self.__client.delete(self.__path)
        except (NoNodeError, NotEmptyError):
            pass

    def __watch_session(self, state):
        self.__wake_event.set()

    def __watch_predecessor(self, event):
        self.__wake_event.set()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self.acquired():
            self.release()


class InterruptableLock(object):
    """
    This lock wraps the specified kazoo lock to provide the following functionality:

    If kazoo connection breaks between acquire() and release() the greenlet will be killed with LockIsLostError. This
    exception will be raised only between acquire() and release() calls, so any connection error after release() won't
    raise anything. Please notice that LockIsLostError is derived from BaseException. This is done to get more
    guarantees that the code will be actually interrupted.

    __exit__() translates LockIsLostError into ConnectionError which is derived from KazooException, so you can catch
    any errors outside of context manager with `except Exception` clause.

    TODO: At this time lock assumed as lost even when connection gets SUSPENDED state. Consider to not account SUSPENDED
    state as error.

    Attention: this lock must be used only in gevent:
    * Interruption works only in gevent.
    * The code is not thread-safe.
    """

    def __init__(self, client, path, lock_class=Lock, **kwargs):
        self.__lock = lock_class(client, path, **kwargs)
        self.__greenlet = None
        self.__acquired = False
        self.__interrupted = False

    def acquire(self, *args, **kwargs):
        if self.__acquired:
            raise RuntimeError("The lock is already acquired.")

        client = self.__lock.client

        # At this time discard all connection states except CONNECTED.
        # If we want support intermediate (SUSPENDED) state we must also track session changes.
        if client.client_state != KazooState.CONNECTED:
            raise ConnectionError()

        if not self.__lock.acquire(*args, **kwargs):
            return False

        try:
            if client.client_state != KazooState.CONNECTED:
                raise ConnectionError()

            self.__greenlet = gevent.getcurrent()
            client.add_listener(self.__listener)
            self.__interrupted = False
            self.__acquired = True
        except:
            client.remove_listener(self.__listener)
            self.__lock.release()
            raise

        return True

    def acquired(self):
        return self.__acquired

    def release(self):
        if not self.__acquired:
            raise RuntimeError("The lock is not acquired.")

        # Notice: be very careful in placing something above this line: we must ensure that gevent won't switch between
        # __exit__() call and this line and don't kill us here.
        self.__acquired = False
        self.__lock.client.remove_listener(self.__listener)

        self.__lock.release()

    def __listener(self, state):
        if state == KazooState.CONNECTED or not self.__acquired or self.__interrupted:
            return

        log.error("ZooKeeper connection has changed its state (now it's %s). Aborting lock on %s...",
                  state, self.__lock.path)

        # Notice: be very careful in placing something below this line: we must ensure that gevent won't switch.

        # Retry the check in case gevent has switched on logging
        if not self.__acquired or self.__interrupted:
            log.error("Cancelling abortion of lock on %s: %s.", self.__lock.path,
                      "it's already interrupted" if self.__acquired else "it's not acquired already")
            return

        self.__interrupted = True

        try:
            error = LockIsLostError("Lock on {} is lost due to connection error.".format(self.__lock.path))
            gevent.kill(self.__greenlet, error)
        except Exception:
            log.exception("Failed to abort lock on %s:", self.__lock.path)

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.acquired():
            try:
                self.release()
            except Exception:
                log.exception("Failed to release lock on %s:", self.__lock.path)

        if isinstance(exc_val, LockIsLostError):
            raise exc_val.to_exception()


class InterruptableKazooLock(InterruptableLock):
    """InterruptableLock that uses kazoo's locks.

    See InterruptableLock for details.
    """

    def __init__(self, *args, **kwargs):
        super(InterruptableKazooLock, self).__init__(*args, lock_class=KazooLock, **kwargs)


def register_lock_path(path):
    """Registers a lock node."""

    _GC.add_lock_path(path)


def register_lock_parent_path(path):
    """Registers a locks parent node."""

    _GC.add_lock_parent_path(path)


def start_gc(client, scheduler):
    """Starts the Garbage Collector."""

    name = "Garbage Collector for ZooKeeper locks"
    # Give a little time to accumulate lock info.
    # Yes, this is not a very elegant way, but it's the simplest one that works for us at this time.
    start_date = datetime.datetime.now() + datetime.timedelta(seconds=random.randint(5, 59))
    scheduler.add_job(_GC.run, "interval", args=[client], name=name, start_date=start_date, minutes=30)


def lost_lock_retry(callable):
    """Wraps a callable object to retry calls that raise LockIsLostError."""

    def wrapper(*args, **kwargs):
        error = None

        while True:
            try:
                if error is not None:
                    log.error("Retry %s call due to error: %s", callable, error)

                result = callable(*args, **kwargs)
            except LockIsLostError as e:
                error = e
            else:
                if error is None:
                    return result
                else:
                    raise error

    return wrapper


class _GarbageCollector(object):
    """
    Implementation of this module's Lock differs from kazoo.recipe.lock.Lock and requires garbage collection (for edge
    cases). Garbage Collector should delete lock paths which may leak due to termination of a client that obtained a
    lock or due to network errors.

    When Lock.__init__() called only with `path` parameter (without `name` parameter) it creates a lock at the specified
    path and adds this path to Garbage Collector's watch list (this path won't be automatically removed from Garbage
    Collector). This is OK for lonely global locks but when you create separate locks for every object there is no need
    to add every such object to the Garbage Collector's watch list. You only need to add a parent node of all such
    locks.

    When Lock.__init__() called with `path` and `name` the following actions will be processed:
    * The lock will be created at `path + "/" + name`.
    * `path` will be added to Garbage Collector's watch list as a node every empty child of which can be deleted.

    By this we assume that:
    * This lock is not a lonely lock.
    * `path` is a node that groups all locks of this type.
    * Garbage Collector can safely delete any empty child node of `path`.

    It's recommended to manually register lock nodes via `register_lock_path()` and `register_lock_parent_path()`. In
    other case the Garbage Collector will learn about them only after first access to these locks.

    The Garbage Collector isn't started automatically. You must start it manually by calling `start_gc()`.
    """

    def __init__(self):
        self.__lock_paths = set()
        self.__lock_parent_paths = set()
        self.__data_lock = threading.Lock()

    def add_lock_path(self, path):
        with self.__data_lock:
            self.__lock_paths.add(path)

    def add_lock_parent_path(self, path):
        with self.__data_lock:
            self.__lock_parent_paths.add(path)

    def run(self, client):
        with self.__data_lock:
            paths = self.__lock_paths.copy()
            parent_paths = self.__lock_parent_paths.copy()

        try:
            for path in parent_paths:
                try:
                    locks = client.get_children(path)
                except NoNodeError:
                    pass
                else:
                    for lock in locks:
                        paths.add(path + "/" + lock)

            for path in paths:
                try:
                    client.delete(path)
                except (NoNodeError, NotEmptyError):
                    pass
        except Exception as e:
            log.error("Lock garbage collection failed: %s", e)


def _retry_on(func, exception, on_retry=None, max_tries=100):
    """Retries the function call while it raises the specified exception."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        tries = max_tries

        while True:
            try:
                return func(*args, **kwargs)
            except exception:
                if tries <= 1:
                    raise

                tries -= 1
                if on_retry is not None:
                    on_retry()

    return wrapper


_GC = _GarbageCollector()