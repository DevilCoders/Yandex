"""
Utilities to work with file descriptors.
"""
from .util import *
