"""
Retrieve peer process user id from UNIX domain socket.
"""
from sys import platform

if platform.startswith('freebsd'):
    from .freebsd import getpeerid
elif platform.startswith('linux'):
    from .linux import getpeerid
else:
    raise RuntimeError("no getpeerid function: platform={0}".format(platform))
