"""
Utilities to get stuff from subversion.
"""
import os
import logging
from xml.etree import cElementTree

from gevent import spawn_later
from gevent.subprocess import Popen, PIPE


log = logging.getLogger(__name__)


class SvnFile(object):
    TIMEOUT = 30
    SVN = 'svn'

    def __init__(self, url, keypath=None, login=None, exe=SVN, timeout=TIMEOUT):
        self.url = url
        self.keypath = keypath
        self.login = login
        self.exe = exe
        self.timeout = timeout

    def _genenv(self):
        env = {}
        if 'SVN_SSH' not in os.environ:
            ssh_args = ['ssh', '-q']
            if self.keypath:
                ssh_args.extend(['-i', "'{0}'".format(self.keypath)])
            if self.login:
                ssh_args.extend(['-l', self.login])
            env['SVN_SSH'] = " ".join(ssh_args)
        else:
            env['SVN_SSH'] = os.environ['SVN_SSH']
        return env

    def _run_subprocess(self, args, env):
        cmdline = ' '.join(args)
        log.info("Spawning: {0} with timeout {1}".format(cmdline, self.timeout))
        process = Popen(args,
                        stdin=PIPE,
                        stdout=PIPE,
                        stderr=PIPE,
                        env=env,
                        close_fds=True)
        killer = spawn_later(self.timeout, process.kill)
        stdout, stderr = process.communicate()
        if not killer.ready():
            killer.kill()
        if process.returncode != 0:
            raise RuntimeError("Process '{0}' finished with {1}".format(cmdline, process.returncode))
        return stdout, stderr

    def export(self, dest):
        args = [self.exe, 'export', self.url, dest]
        self._run_subprocess(args, self._genenv())

    def cat(self):
        args = [self.exe, 'cat', self.url]
        stdout, _ = self._run_subprocess(args, env=self._genenv())
        return stdout

    def get_last_rev(self):
        args = [self.exe, 'info', '--xml', self.url]
        stdout, _ = self._run_subprocess(args, self._genenv())
        tree = cElementTree.fromstring(stdout)
        committag = tree.find('entry/commit')
        if not committag:
            raise Exception('Failed to find revision in svn info output')
        return int(committag.get('revision'))
