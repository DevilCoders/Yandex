# -*- coding: utf-8 -*-
from sepelib.util.retry import Retry, RetrySleeper
from sepelib.yandex.kafka_http_proxy.client import KafkaMessage
from sepelib.yandex.kafka_http_proxy.errors import KafkaTopicOffsetOutOfRangeError


class KafkaHttpProxyPartitionConsumer(object):
    """
    Consumer for the single partition of a topic
    """

    MESSAGE_BATCH_LIMIT = 1000
    DEFAULT_MAX_CONSUME_DELAY = 3.0

    def __init__(self, topic, partition, consumer_group, client, retry_sleeper=None,
                 batch_size=MESSAGE_BATCH_LIMIT, auto_commit_after=None):
        """
        :param retry_sleeper: sleeper for message consume attempts when no new messages available

        :type topic: str | unicode
        :type partition: int
        :type consumer_group: str | unicode
        :type client: sepelib.yandex.kafka.client.KafkaHttpProxyClient
        :type batch_size: int
        :type auto_commit_after: int | NoneType
        :type retry_sleeper: sepelib.util.retry.RetrySleeper
        """
        self._topic = topic
        self._partition = partition
        self._client = client
        self._consumer_group = consumer_group
        self._batch_size = batch_size
        self._auto_commit_after = auto_commit_after
        self._retry = Retry(retry_sleeper=retry_sleeper or RetrySleeper(max_delay=self.DEFAULT_MAX_CONSUME_DELAY),
                            retry_exceptions=(KafkaTopicOffsetOutOfRangeError,))

    def iter_messages(self, from_offset=None):
        """
        :type from_offset: int | NoneType
        :rtype: collections.Iterable[KafkaMessage]
        """
        if from_offset is None:
            # Kafka may response that there is no offset ever committed for given consumer group
            # in practice it may be done due to data inconsistency: KAFKA-1211.
            # We raise up such error instead of read messages from zero offset to avoid
            # re-reading lots of data
            from_offset = self._client.fetch_offset(consumer_group=self._consumer_group,
                                                    topic=self._topic,
                                                    partition=self._partition)

        i = 0
        while True:
            batch = self._retry(self._client.consume,
                                topic=self._topic,
                                partition=self._partition,
                                offset=from_offset,
                                limit=self._batch_size)

            for i, message in enumerate(batch.messages, start=i + 1):
                yield KafkaMessage(message=message, offset=from_offset)
                from_offset += 1
                if self._auto_commit_after is not None and i % self._auto_commit_after == 0:
                    self.commit_offset(from_offset)

    def commit_offset(self, offset):
        """
        :type offset: int
        """
        self._client.commit_offset(consumer_group=self._consumer_group,
                                   topic=self._topic,
                                   partition=self._partition,
                                   offset=offset)
