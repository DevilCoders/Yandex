# -*- coding: utf-8 -*-
"""
Client for kafka-http-proxy: https://github.com/legionus/kafka-http-proxy
"""
import httplib
import json

import gevent
import requests

from sepelib.http.session import InstrumentedSession
from sepelib.yandex.kafka_http_proxy import errors


class KafkaPartitionOffset(object):

    __slots__ = ['partition', 'offset']

    def __init__(self, partition, offset):
        self.partition = partition
        self.offset = offset

    @classmethod
    def from_kafka_proxy_response(cls, params):
        """
        :type params: dict
        :rtype: KafkaPartitionOffset
        """
        return cls(partition=params['partition'], offset=params['offset'])

    def __repr__(self):
        return 'KafkaPartitionOffset(partition={!r}, offset={!r})'.format(self.partition, self.offset)

    __str__ = __repr__


class KafkaMessage(object):

    __slots__ = ['message', 'offset']

    def __init__(self, message, offset):
        self.message = message
        self.offset = offset

    def __repr__(self):
        return 'KafkaMessage(message={!r}, offset={!r})'.format(self.message, self.offset)

    __str__ = __repr__


class KafkaMessageSet(object):

    __slots__ = ['messages']

    def __init__(self, messages):
        """
        :type messages: list
        """
        self.messages = messages

    @classmethod
    def from_kafka_proxy_response(cls, params):
        """
        :type params: dict
        :rtype: KafkaMessageSet
        """
        return cls(messages=params['messages'])

    def __repr__(self):
        return 'KafkaMessageSet(messages={!r})'.format(self.messages)

    __str__ = __repr__


class KafkaTopicInfo(object):

    __slots__ = ['partitions']

    def __init__(self, partitions):
        """
        :type partitions: list
        """
        self.partitions = partitions

    @classmethod
    def from_kafka_proxy_response(cls, params):
        """
        :type params: dict
        :rtype: KafkaTopicInfo
        """
        return cls(partitions=params['data'])

    def __repr__(self):
        return 'KafkaTopicInfo(partitions={!r})'.format(self.partitions)

    __str__ = __repr__


class IKafkaHttpProxyClient(object):

    def produce(self, message, topic, partition):
        """
        Puts :param message: to the kafka :param topic:.

        :type message: dict | list | tuple
        :type topic: str | unicode
        :type partition: int | NoneType

        :rtype: KafkaPartitionOffset
        """
        raise NotImplementedError

    def consume(self, topic, partition, offset, limit=1):
        """
        Gets batch of messages from :param partition: of a :param topic:

        :type topic: str | unicode
        :type partition: int
        :type offset: int
        :type limit: int

        :rtype: KafkaMessageSet
        """
        raise NotImplementedError

    def commit_offset(self, consumer_group, topic, partition, offset):
        """
        Commits offset up to which messages have been consumed by :param consumer_group:

        :type consumer_group: str | unicode
        :type topic: str | unicode
        :type partition: int
        :type offset: int
        """
        raise NotImplementedError

    def fetch_offset(self, consumer_group, topic, partition):
        """
        Fetches topic offset of a :param consumer_group:

        :type consumer_group: str | unicode
        :type topic: str | unicode
        :type partition: int

        :rtype: int
        """
        raise NotImplementedError

    def get_topic_info(self, topic):
        """
        Gets info about partitions of a :param topic:

        :type topic: str | unicode
        :rtype: KafkaTopicInfo
        """
        raise NotImplementedError


class KafkaHttpProxyClient(IKafkaHttpProxyClient):

    DEFAULT_REQUEST_TIMEOUT = 10.0
    DEFAULT_OK_STATUSES = (httplib.OK,)

    def __init__(self, url, req_timeout=DEFAULT_REQUEST_TIMEOUT):
        """
        :param url: kafka-http-proxy url
        :type url: str | unicode
        :type req_timeout: int | float
        """
        self._url = url.rstrip('/')
        self._req_timeout = req_timeout
        self._session = InstrumentedSession('/clients/kafka-http-proxy')

    @classmethod
    def from_config(cls, config):
        return cls(url=config['url'],
                   req_timeout=config.get('req_timeout', cls.DEFAULT_REQUEST_TIMEOUT))

    def _request(self, method, url, data=None, ok_statuses=DEFAULT_OK_STATUSES):
        """
        :type url: str | unicode
        :type data: str | unicode
        """
        try:
            with gevent.Timeout(self._req_timeout):
                resp = self._session.request(method, url, data=data)
        except gevent.Timeout:
            raise errors.KafkaHttpProxyRequestTimeout
        except requests.RequestException as e:
            raise errors.KafkaHttpProxyClientError(e, request=getattr(e, 'request'), response=getattr(e, 'response'))

        if resp.status_code not in ok_statuses:
            raise errors.KafkaHttpProxyClientError('Kafka request failed: {}'.format(resp), response=resp)

        return resp

    def produce(self, message, topic, partition):
        url = '{}/v1/topics/{}/{}'.format(self._url, topic, partition)

        try:
            dump = json.dumps(message)
        except Exception as e:
            raise errors.KafkaHttpProxyClientError('Cannot encode message to JSON: {}'.format(e))

        response = self._request('POST', url, data=dump)
        return KafkaPartitionOffset.from_kafka_proxy_response(response.json()['data'])

    def consume(self, topic, partition, offset, limit=1):
        url = '{}/v1/topics/{}/{}?offset={}&limit={}'.format(self._url, topic, partition, offset, limit)
        response = self._request('GET', url, ok_statuses=(httplib.OK, httplib.REQUESTED_RANGE_NOT_SATISFIABLE))
        if response.status_code == httplib.REQUESTED_RANGE_NOT_SATISFIABLE:
            raise errors.KafkaTopicOffsetOutOfRangeError(response=response)
        return KafkaMessageSet.from_kafka_proxy_response(response.json()['data'])

    def commit_offset(self, consumer_group, topic, partition, offset):
        url = '{}/v1/consumers/{}/topics/{}/{}'.format(self._url, consumer_group, topic, partition)
        self._request('PUT', url, data='{{"offset": {}}}'.format(offset))

    def fetch_offset(self, consumer_group, topic, partition):
        url = '{}/v1/consumers/{}/topics/{}/{}'.format(self._url, consumer_group, topic, partition)
        response = self._request('GET', url, ok_statuses=(httplib.OK, httplib.NOT_FOUND))

        if response.status_code == httplib.NOT_FOUND:
            raise errors.KafkaOffsetNotFoundError(response=response)

        return response.json()['data']['offset']

    def get_topic_info(self, topic):
        url = '{}/v1/info/topics/{}'.format(self._url, topic)
        resp = self._request('GET', url)
        return KafkaTopicInfo.from_kafka_proxy_response(resp.json())
