"""
Passport client which tries to reuse connections.
"""
from collections import namedtuple
from logging import getLogger

from sepelib.http.session import InstrumentedSession

from .blackbox import validate_session_id, validate_oauth_token, FIELD_LOGIN, BLACKBOX_URL, BLACKBOX_AUTH_URL


log = getLogger(__name__)


PassportCheckResult = namedtuple('PassportCheckResult', ['login', 'redirect_url'])

OAuthCheckResult = namedtuple('OAuthCheckResult', ['login', 'client_id', 'error'])


class IPassportClient(object):
    """
    Interface to be used in dependency injection.
    """
    pass


class PassportClient(IPassportClient):
    _REQ_TIMEOUT = 10

    @classmethod
    def from_config(cls, d):
        return cls(blackbox_url=d.get('blackbox_url'),
                   blackbox_auth_url=d.get('blackbox_auth_url'),
                   req_timeout=d.get('req_timeout'))

    def __init__(self, blackbox_url=BLACKBOX_URL, blackbox_auth_url=BLACKBOX_AUTH_URL, req_timeout=None):
        self._blackbox_url = blackbox_url
        self._blackbox_auth_url = blackbox_auth_url
        self._req_timeout = req_timeout or self._REQ_TIMEOUT
        self._session = InstrumentedSession('/clients/passport')

    def check_passport_cookie(self, cookies, host, user_ip, request_url):
        """
        Check passport cookie.
        :param cookies: dict-like object containing cookies,
                        e.g. :attr:`flask.request.cookies`)
        :param host: requested host, e.g. :attr:`flask.request.host`
        :param user_ip: user ip, e.g. the first element of :attr:`flask.request.access_route`
        :param request_url: URL to redirect a user to after successful authentication
        :rtype: PassportCheckResult
        """
        session_id = cookies.get('Session_id')
        if not session_id:
            return PassportCheckResult(login=None, redirect_url=self._blackbox_auth_url.format(request_url))
        if ':' in host:
            host = host.split(':')[0]
        valid, need_redirect, dbfields = validate_session_id(session_id,
                                                             user_ip, host,
                                                             [FIELD_LOGIN],
                                                             timeout=self._req_timeout,
                                                             url=self._blackbox_url,
                                                             session=self._session)
        if not valid or need_redirect:
            return PassportCheckResult(login=None, redirect_url=self._blackbox_auth_url.format(request_url))
        # put login to lowercase
        # otherwise users like 'nARN' can get in trouble
        login = dbfields[FIELD_LOGIN].lower()
        log.info("authenticated via blackbox: login='{0}' ip='{1}'".format(login, user_ip))
        return PassportCheckResult(login=login, redirect_url=None)

    def check_oauth_token(self, user_ip, oauth_token=None, authorization_header=None):
        """
        Check OAuth token.
        :param oauth_token: OAuth token or entire content of Authorization header
        :param user_ip: user ip, e.g. the first element of :attr:`flask.request.access_route`
        :rtype: PassportCheckResult
        """
        assert (oauth_token or authorization_header) and not (oauth_token and authorization_header)
        valid, fields, client_id, error = validate_oauth_token(
            oauth_token=oauth_token,
            authorization_header=authorization_header,
            userip=user_ip,
            fields=[FIELD_LOGIN],
            timeout=self._req_timeout,
            url=self._blackbox_url,
            session=self._session)
        if valid:
            return OAuthCheckResult(login=fields[FIELD_LOGIN], client_id=client_id, error=None)
        else:
            return OAuthCheckResult(login=None, client_id=client_id, error=error)

    ### to be consistent with other services
    def start(self):
        pass

    def stop(self):
        self._session.close()
