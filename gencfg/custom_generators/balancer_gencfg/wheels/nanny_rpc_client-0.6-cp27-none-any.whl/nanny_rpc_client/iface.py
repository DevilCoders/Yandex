class IHttpRpcClient(object):
    """
    Interface which every HTTP RPC client must complain.
    """
    def call_remote_method(self, method_name, request_protobuf, response_protobuf, **kwargs):
        """
        Invokes remote method on server by issuing properly crafted HTTP POST request.
        :param method_name: remote method name (e.g. 'SayHello')
        :param request_protobuf: request object - protobuf message
        :param response_protobuf: response object, which will be filled with server response
        :param kwargs: additional information depending on actual implementation (e.g. override parameters)
        """
        raise NotImplementedError
