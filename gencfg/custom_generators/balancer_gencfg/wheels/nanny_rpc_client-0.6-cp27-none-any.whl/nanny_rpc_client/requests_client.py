import time

import requests

from . import exceptions
from . import iface
from . import proto


def make_exception_from_pb(error):
    exc_class = exceptions.errors_by_code.get(error.code)
    if exc_class is None:
        raise RuntimeError('Unsupported response code for error: {}'.format(error))
    return exc_class(error.message, redirect_url=error.redirect_url)


class RequestParams(object):
    def __init__(self):
        self._oauth_token = None
        self._session_id = None
        self._request_timeout = None

    def copy(self):
        rv = RequestParams()
        rv.oauth_token = self._oauth_token
        rv.session_id = self._session_id
        rv.request_timeout = self._request_timeout
        return rv

    def merge(self, kwargs):
        if 'oauth_token' in kwargs:
            self.oauth_token = kwargs['oauth_token']
        if 'session_id' in kwargs:
            self.session_id = kwargs['session_id']
        if 'request_timeout' in kwargs:
            self.request_timeout = kwargs['request_timeout']

    @property
    def oauth_token(self):
        return self._oauth_token

    @oauth_token.setter
    def oauth_token(self, value):
        if value and self._session_id:
            raise ValueError('Cannot set token, session_id already set. Please choose only one.')
        self._oauth_token = value

    @property
    def session_id(self):
        return self._session_id

    @session_id.setter
    def session_id(self, value):
        if value and self._oauth_token:
            raise ValueError('Cannot set session_id, oauth_token already set. Please choose only one.')
        self._session_id = value

    @property
    def request_timeout(self):
        return self._request_timeout

    @request_timeout.setter
    def request_timeout(self, value):
        if value is None:
            self._request_timeout = None
            return
        if not isinstance(value, (int, float)):
            raise TypeError('Value must be integer or float, got {0}'.format(type(value)))
        if value < .1:
            raise ValueError('Min value is .1, got {0}'.format(value))
        if value > 120:
            raise ValueError('Max value is 120, got {0}'.format(value))
        self._request_timeout = value


class RequestsRpcClient(iface.IHttpRpcClient):
    """
    Implementation of HTTP RPC client, which uses requests library to perform calls.
    """
    DEFAULT_HEADERS = {
        'Accept': 'application/x-protobuf',
        'Content-Type': 'application/x-protobuf',
        'User-Agent': 'Python RequestsRpcClient'
    }

    def __init__(self, rpc_url, oauth_token=None, session_id=None, request_timeout=10):
        self._rpc_url = None
        self.rpc_url = rpc_url
        params = RequestParams()
        params.oauth_token = oauth_token
        params.session_id = session_id
        params.request_timeout = request_timeout
        self._request_params = params

    # ########### Getters/setters part
    @property
    def rpc_url(self):
        return self._rpc_url

    @rpc_url.setter
    def rpc_url(self, value):
        if not value.startswith('http://') and not value.startswith('https://'):
            raise ValueError('RPC URL must start with http(s): {0}'.format(value))
        self._rpc_url = value.rstrip('/')

    # ########### Interface implementation
    def call_remote_method(self, method_name, request_protobuf, response_protobuf, **kwargs):
        url = '{0}/{1}/'.format(self.rpc_url, method_name)
        # Prepare request params if something is overridden
        if kwargs:
            params = self._request_params.copy()
            params.merge(kwargs)
        else:
            params = self._request_params
        headers = RequestsRpcClient.DEFAULT_HEADERS.copy()
        # Set authentication headers
        if params.oauth_token:
            headers['Authorization'] = 'OAuth ' + params.oauth_token
        if params.session_id:
            headers['Cookie'] = 'Session_id={0};'.format(params.session_id)
        kwargs = {
            'allow_redirects': False,
            'data': request_protobuf.SerializeToString(),
            'headers': headers,
            'timeout': params.request_timeout
        }
        response = requests.post(url, **kwargs)
        if response.status_code == 200:  # Response is ok, deserialize
            response_protobuf.MergeFromString(response.content)
            return
        # Error happened, read from body and raise exception
        error_protobuf = proto.status_pb2.Status()
        try:
            error_protobuf.MergeFromString(response.content)
        except Exception:
            # Failed to load protobuf error response
            raise RuntimeError('Invalid response from server: {0}'.format(response.content))
        raise make_exception_from_pb(error_protobuf)


class SessionedRpcClient(iface.IHttpRpcClient):
    """
    Implementation of HTTP RPC client, which uses requests library to perform calls
    and tries to reuse connection using requests.Session().

    Don't forget to call .close() to close connections after use.

    Warning: please use with caution as sessions may rot if not used for some time and subsequent
    requests will fail with connection errors.
    """
    DEFAULT_HEADERS = {
        'Accept': 'application/x-protobuf',
        'Content-Type': 'application/x-protobuf',
        'User-Agent': 'Python RequestsRpcClient'
    }

    def __init__(self, rpc_url, oauth_token=None, session_id=None, request_timeout=10, sleep_func=time.sleep):
        self._rpc_url = None
        self.rpc_url = rpc_url
        params = RequestParams()
        params.oauth_token = oauth_token
        params.session_id = session_id
        params.request_timeout = request_timeout
        self._request_params = params
        self._session = requests.Session()
        self._sleep_func = sleep_func

    def close(self):
        self._session.close()

    # ########### Getters/setters part
    @property
    def rpc_url(self):
        return self._rpc_url

    @rpc_url.setter
    def rpc_url(self, value):
        if not value.startswith('http://') and not value.startswith('https://'):
            raise ValueError('RPC URL must start with http(s): {0}'.format(value))
        self._rpc_url = value.rstrip('/')

    # ########### Interface implementation
    def call_remote_method(self, method_name, request_protobuf, response_protobuf, **kwargs):
        url = '{0}/{1}/'.format(self.rpc_url, method_name)
        # Prepare request params if something is overridden
        if kwargs:
            params = self._request_params.copy()
            params.merge(kwargs)
        else:
            params = self._request_params
        headers = RequestsRpcClient.DEFAULT_HEADERS.copy()
        # Set authentication headers
        if params.oauth_token:
            headers['Authorization'] = 'OAuth ' + params.oauth_token
        if params.session_id:
            headers['Cookie'] = 'Session_id={0};'.format(params.session_id)
        kwargs = {
            'allow_redirects': False,
            'data': request_protobuf.SerializeToString(),
            'headers': headers,
            'timeout': params.request_timeout
        }
        for i in xrange(1, 11):
            response = self._session.post(url, **kwargs)
            if response.status_code == 429:  # TooManyRequestsError, retry
                self._sleep_func(i)
            elif response.status_code == 200:  # Response is ok, deserialize
                response_protobuf.MergeFromString(response.content)
                return
            else:
                break
        # Error happened, read from body and raise exception
        error_protobuf = proto.status_pb2.Status()
        try:
            error_protobuf.MergeFromString(response.content)
        except Exception:
            # Failed to load protobuf error response
            raise RuntimeError('Invalid response from server: {0}'.format(response.content))
        raise make_exception_from_pb(error_protobuf)
