"""
Remote procedure call utilities.
"""
