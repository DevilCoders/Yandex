# coding=utf-8

"""
    Simple module to perform thrift calls
"""
