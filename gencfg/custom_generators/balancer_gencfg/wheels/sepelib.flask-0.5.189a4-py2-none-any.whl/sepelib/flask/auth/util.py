def login_exempt(view):
    """
    A decorator that can exclude a view from authentication and authorization processes.

    :param view: flask request handling function
    """
    view.need_auth = False
    return view
